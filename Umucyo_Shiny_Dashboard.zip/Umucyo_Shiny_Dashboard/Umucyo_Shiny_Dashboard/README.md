# Umucyo Supermarket: R Shiny dashboard (deployable folder)

```
Umucyo_Shiny_Dashboard/
├── run_dashboard.R               <- 1. open the dashboard on your computer
├── deploy_to_shinyapps.R         <- 2. publish it online (shinyapps.io)
├── sync_data_into_dashboard.R    <- helper used by both (no need to open)
└── dashboard/                    <- THE APP: this whole folder is what gets published
    ├── app.R
    ├── data/processed/retail_integrated_clean.csv   (required)
    ├── data/processed/customers_cleaned.csv, products_cleaned.csv   (optional)
    ├── data/raw/transactions.csv, customers.csv, products.csv       (optional, Data Quality tab)
    └── outputs/tables/cleaning_log.csv, removed_rows.csv            (optional, Data Quality tab)
```

## Step 0: the data (already done)
Your data files are already copied into `dashboard/`. When you rerun the Python notebook, `run_dashboard.R` and `deploy_to_shinyapps.R` copy the newer files in automatically. They look in this folder, then up to three folders higher, which reaches `submission\data` from `submission\r\Umucyo_Shiny_Dashboard`. Finally they check your submission folder path, which is set as `PROJECT_FOLDER` in `app.R` and in `sync_data_into_dashboard.R`.

Only `retail_integrated_clean.csv` is required. Without the optional files, the "Data Quality" tab just shows less.

## Step 1: run it on your computer
1. Open `run_dashboard.R` in RStudio.
2. Click **Source**, or press Ctrl + Shift + S.
3. The first time, the missing packages are installed. This needs internet and takes a few minutes.
4. The dashboard opens in your browser.

## Step 2: publish it online (free)
Your account (`datawiserwanda`), token and secret are already in STEP 1 of `deploy_to_shinyapps.R`.
1. Open `deploy_to_shinyapps.R` in RStudio.
2. Click **Source**. Uploading and installing takes about 3–5 minutes.
3. Your link opens automatically: **https://datawiserwanda.shinyapps.io/umucyo-dashboard/**
4. To update the online version later, run the same file again.

Your shinyapps.io password is never needed.

**Before you submit or share this folder,** replace the token and secret in STEP 1 with `PASTE-YOUR-TOKEN-HERE` and `PASTE-YOUR-SECRET-HERE`. RStudio remembers your account, so later updates still work. If the token was ever shared, create a new one on the Tokens page and delete the old one.

## What changed compared with the original code
- `app.R` is your dashboard. All tabs, charts and tests are unchanged. Three small changes make it deployable:
  1. The automatic package installer only runs on your own computer. On a Shiny server, packages are installed at deploy time.
  2. The app reads its data from inside the `dashboard/` folder, because a deployed app can only see its own folder. On your computer it also looks up to three folders higher and in your `PROJECT_FOLDER`.
  3. Clearer error messages when the data file is missing.
- `run_dashboard.R` copies your data into `dashboard/` before starting, so the folder you test is exactly the folder you publish. It also works with `Rscript`.
- `deploy_to_shinyapps.R` is new. It installs `rsconnect`, copies the data, and uploads only `app.R` and the data files.

## Troubleshooting
- **"retail_integrated_clean.csv was not found":** run the Python notebook first, or copy the file into `dashboard/data/processed/`.
- **Packages fail to install:** your network may block CRAN. Try a phone hotspot, restart R (Session > Restart R) and run again.
- **Deploy error about the account:** check that ACCOUNT_NAME is exactly the name shown in your shinyapps.io address.
- **App works locally but shows an error online:** in shinyapps.io open your app and look at **Logs**. The most common cause is a data file that was not copied into `dashboard/`.
