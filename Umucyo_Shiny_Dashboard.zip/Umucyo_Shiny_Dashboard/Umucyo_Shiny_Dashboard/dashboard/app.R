# =============================================================================
#  Umucyo Supermarket – Retail Market Intelligence Dashboard (R Shiny)
#  Programming for Data Scientists (Python and R) · ACE-DS, University of Rwanda
#
#  Uses the SAME final dataset as the Python notebook and the R script:
#      data/processed/retail_integrated_clean.csv
#
#  DEPLOYABLE VERSION
#    All files the app needs live INSIDE this "dashboard" folder:
#      dashboard/app.R
#      dashboard/data/processed/retail_integrated_clean.csv      (required)
#      dashboard/data/processed/customers_cleaned.csv, products_cleaned.csv   (optional)
#      dashboard/data/raw/transactions.csv, customers.csv, products.csv        (optional, Data Quality tab)
#      dashboard/outputs/tables/cleaning_log.csv, removed_rows.csv            (optional, Data Quality tab)
#    so the folder can be published to shinyapps.io / Posit Connect as it is.
#
#  HOW TO RUN ON YOUR COMPUTER
#    Open run_dashboard.R (one folder up) in RStudio and click "Source",
#    or open THIS file and click the green "Run App" button.
#  HOW TO PUBLISH ONLINE
#    Open deploy_to_shinyapps.R (one folder up), fill in your account details and click "Source".
# =============================================================================

# ---- Step 0: install any missing packages automatically (on YOUR computer only) --
# Some networks block cloud.r-project.org, so we try several download servers.
# The warning "Rtools is required to build R packages" can be ignored.
# On a Shiny server (shinyapps.io sets SHINY_PORT) packages are installed at deploy
# time from the library() calls below, so this step is skipped there.
if (!nzchar(Sys.getenv("SHINY_PORT")) && !nzchar(Sys.getenv("RSTUDIO_CONNECT_HASTE")) && interactive()) local({
  needed  <- c("shiny", "bslib", "plotly", "DT", "dplyr", "tidyr", "readr")
  mirrors <- c("https://cran.rstudio.com", "https://packagemanager.posit.co/cran/latest",
               "https://cloud.r-project.org")
  is_missing <- function() needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
  if (length(is_missing()) > 0) {
    options(timeout = max(600, getOption("timeout")))
    pkg_type <- if (.Platform$OS.type == "windows") "binary" else getOption("pkgType")
    for (repo in mirrors) {
      todo <- is_missing()
      if (length(todo) == 0) break
      message("Installing ", paste(todo, collapse = ", "), " from ", repo, " ...")
      try(install.packages(todo, repos = repo, type = pkg_type), silent = TRUE)
    }
    still <- is_missing()
    if (length(still) > 0) {
      stop("Could not install: ", paste(still, collapse = ", "),
           ".\nYour network is blocking the downloads. Connect to another network (for example a phone ",
           "hotspot), restart R (Session > Restart R) and run the app again.", call. = FALSE)
    }
  }
})

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
  library(plotly)
  library(DT)
  library(dplyr)
  library(tidyr)
  library(readr)
})

# ---- Locate project files (works when started from the project or dashboard/) --
# Your project folder on your own computer (used only when the data has not been copied
# into dashboard/ yet; the online version always uses the copy inside dashboard/).
PROJECT_FOLDER <- "C:/Users/tharagirimana/OneDrive - LOLC UNGUKA FINANCE/Desktop/Thacien/Masters In data science/retail_market_intelligence/retail_market_intelligence/submission"

# Looks first inside the dashboard folder (needed for online deployment), then up to three
# folders higher (e.g. submission/r/Umucyo_Shiny_Dashboard/dashboard -> submission), then PROJECT_FOLDER.
find_file <- function(rel) {
  for (p in c(rel, file.path("..", rel), file.path("../..", rel), file.path("../../..", rel),
              file.path(PROJECT_FOLDER, rel))) if (file.exists(p)) return(p)
  stop("Cannot find '", rel, "'. Copy retail_integrated_clean.csv into dashboard/data/processed/ ",
       "(run_dashboard.R and deploy_to_shinyapps.R do this for you if your project has a data/processed folder).",
       call. = FALSE)
}
CLEAN_FILE <- find_file("data/processed/retail_integrated_clean.csv")
ROOT <- dirname(dirname(dirname(CLEAN_FILE)))
opt_read <- function(...) { f <- file.path(ROOT, ...); if (file.exists(f)) read_csv(f, show_col_types = FALSE) else NULL }

# ---- Load data ----------------------------------------------------------------
retail <- read_csv(CLEAN_FILE, show_col_types = FALSE) |>
  mutate(date = as.Date(transaction_date),
         membership = factor(membership, levels = c("Regular", "Silver", "Gold", "Unknown")),
         day_of_week = factor(day_of_week, levels = c("Monday", "Tuesday", "Wednesday", "Thursday",
                                                      "Friday", "Saturday", "Sunday")))
raw_files <- list(transactions = opt_read("data", "raw", "transactions.csv"),
                  customers    = opt_read("data", "raw", "customers.csv"),
                  products     = opt_read("data", "raw", "products.csv"))
cleaning_log <- opt_read("outputs", "tables", "cleaning_log.csv")
removed_rows <- opt_read("outputs", "tables", "removed_rows.csv")

# ---- Design tokens ------------------------------------------------------------
COL <- list(primary = "#2a78d6", orange = "#eb6834", aqua = "#1baf7a", yellow = "#eda100",
            magenta = "#e87ba4", green = "#008300", violet = "#6250d6", red = "#e34948",
            ink = "#1e293b", muted = "#64748b", grid = "#e8edf3")
CAT_COLS <- c(COL$primary, COL$orange, COL$aqua, COL$yellow, COL$magenta, COL$green, COL$violet, COL$red)
MEMBER_COLS <- c(Regular = COL$primary, Silver = COL$orange, Gold = COL$aqua, Unknown = "#94a3b8")
STATUS_COLS <- c(Completed = COL$primary, Returned = COL$orange, Cancelled = COL$red)
PAY_COLS <- c("Mobile Money" = COL$aqua, Cash = COL$yellow, Card = COL$primary, "Bank Transfer" = COL$violet, Unknown = "#b8c2cf")
CATEGORY_COLS <- setNames(CAT_COLS[1:7], c("Baby Products", "Beverages", "Electronics", "Groceries", "Household",
                                           "Personal Care", "Stationery"))
CHANNEL_COLS <- c("In-store" = COL$primary, Online = COL$orange, "Phone order" = COL$aqua)
colour_for <- function(values) {
  lookup <- c(PAY_COLS, MEMBER_COLS, STATUS_COLS, CATEGORY_COLS, CHANNEL_COLS, "TRUE" = COL$orange, "FALSE" = COL$primary)
  out <- unname(lookup[values])
  out[is.na(out)] <- CAT_COLS[(seq_along(values) - 1) %% 8 + 1][is.na(out)]
  out
}

fmt_rwf <- function(x, digits = 1) {
  x <- as.numeric(x)
  ifelse(abs(x) >= 1e6, paste0(formatC(x / 1e6, format = "f", digits = digits), "M"),
         ifelse(abs(x) >= 1e3, paste0(formatC(x / 1e3, format = "f", digits = 0), "K"),
                formatC(x, format = "f", digits = 0, big.mark = ",")))
}
VAR_LABELS <- c(purchases = "Purchases", total_spent = "Total spent (RWF)", avg_sale_value = "Average basket (RWF)",
                recency_days = "Days since last purchase", age = "Age (years)")
fmt_int <- function(x) formatC(x, format = "d", big.mark = ",")
fmt_p   <- function(p) if (p < 0.001) "< 0.001" else sprintf("= %.3f", p)

# A shared Plotly look so every chart feels like one system
style_plot <- function(p, xtitle = NULL, ytitle = NULL, legend = TRUE) {
  p |>
    layout(font = list(family = "Inter, Segoe UI, system-ui, sans-serif", size = 12, color = COL$ink),
           paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "rgba(0,0,0,0)",
           margin = list(l = 10, r = 10, t = 10, b = 10),
           xaxis = list(title = list(text = if (is.null(xtitle)) "" else xtitle), gridcolor = COL$grid,
                        zeroline = FALSE, automargin = TRUE),
           yaxis = list(title = list(text = if (is.null(ytitle)) "" else ytitle), gridcolor = COL$grid,
                        zeroline = FALSE, automargin = TRUE),
           hoverlabel = list(bgcolor = "white", bordercolor = COL$grid, font = list(color = COL$ink)),
           showlegend = legend,
           legend = list(orientation = "h", x = 0, y = 1.12, bgcolor = "rgba(0,0,0,0)")) |>
    config(displaylogo = FALSE,
           modeBarButtonsToRemove = c("lasso2d", "select2d", "autoScale2d", "toggleSpikelines"))
}
empty_plot <- function(msg = "No data for the selected filters") {
  plot_ly() |> layout(annotations = list(text = msg, showarrow = FALSE, font = list(size = 15, color = COL$muted)),
                      xaxis = list(visible = FALSE), yaxis = list(visible = FALSE),
                      paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "rgba(0,0,0,0)") |>
    config(displayModeBar = FALSE)
}

# ---- Theme --------------------------------------------------------------------
theme <- bs_theme(
  version = 5, bg = "#f4f6fb", fg = COL$ink, primary = COL$primary, secondary = COL$muted,
  success = COL$aqua, warning = COL$yellow, danger = COL$red,
  base_font = font_collection(font_google("Inter", local = FALSE), "Segoe UI", "system-ui", "sans-serif"),
  heading_font = font_collection(font_google("Inter", local = FALSE), "Segoe UI", "sans-serif"),
  "border-radius" = "0.9rem", "card-border-color" = "transparent"
)

css <- "
.navbar { background: linear-gradient(90deg, #12355b 0%, #1f5fa8 60%, #2a78d6 100%) !important; box-shadow: 0 2px 12px rgba(18,53,91,.25); }
.navbar .navbar-brand, .navbar .nav-link { color: #ffffff !important; }
.navbar .nav-link { opacity: .78; font-weight: 500; }
.navbar .nav-link.active, .navbar .nav-link:hover { opacity: 1; border-bottom: 2px solid #ffd166; }
.brand-title { font-weight: 800; letter-spacing: .2px; }
.brand-sub { font-weight: 400; opacity: .8; font-size: .85rem; margin-left: .5rem; }
.card { box-shadow: 0 1px 3px rgba(15,23,42,.06), 0 6px 20px rgba(15,23,42,.05); }
.card-header { background: transparent; border-bottom: 1px solid #eef1f6; font-weight: 650; }
.card-header .sub { color: #64748b; font-weight: 400; font-size: .82rem; display: block; }
.bslib-value-box .value-box-title { font-size: .82rem; text-transform: uppercase; letter-spacing: .4px; opacity: .85; }
.bslib-value-box .value-box-value { font-weight: 800; }
.bslib-value-box p { font-size: .82rem; margin-bottom: 0; opacity: .9; }
.sidebar-title { font-weight: 700; color: #12355b; }
.note { font-size: .8rem; color: #64748b; }
.insight { background: #eef5fd; border-left: 4px solid #2a78d6; border-radius: .5rem; padding: .7rem .9rem; margin-bottom: .5rem; font-size: .92rem; }
.insight.good { background: #e9f8f2; border-left-color: #1baf7a; }
.insight.warn { background: #fff6e5; border-left-color: #eda100; }
.stat-big { font-size: 1.9rem; font-weight: 800; color: #12355b; line-height: 1.1; }
.stat-label { font-size: .78rem; color: #64748b; text-transform: uppercase; letter-spacing: .4px; }
table.dataTable tbody td { font-size: .86rem; }
"

card_h <- function(title, sub = NULL) card_header(HTML(paste0(title, if (!is.null(sub)) paste0("<span class='sub'>", sub, "</span>"))))

# ---- Sidebar filters ----------------------------------------------------------
choices_of <- function(x) sort(unique(as.character(x)))
filters <- sidebar(
  width = 285, open = "desktop",
  div(class = "sidebar-title", icon("sliders"), " Filters"),
  dateRangeInput("dates", "Date range", start = min(retail$date), end = max(retail$date),
                 min = min(retail$date), max = max(retail$date), format = "dd M yyyy"),
  selectizeInput("region", "Region", choices_of(retail$region), multiple = TRUE,
                 options = list(placeholder = "All regions")),
  selectizeInput("category", "Product category", choices_of(retail$category), multiple = TRUE,
                 options = list(placeholder = "All categories")),
  selectizeInput("channel", "Sales channel", choices_of(retail$sales_channel), multiple = TRUE,
                 options = list(placeholder = "All channels")),
  selectizeInput("membership", "Membership", levels(retail$membership), multiple = TRUE,
                 options = list(placeholder = "All levels")),
  checkboxGroupInput("status", "Sale status", choices = c("Completed", "Returned", "Cancelled"),
                     selected = c("Completed", "Returned", "Cancelled"), inline = FALSE),
  actionButton("reset", "Reset filters", icon = icon("rotate-left"), class = "btn-outline-primary btn-sm"),
  hr(),
  downloadButton("dl_filtered", "Download filtered data", class = "btn-primary btn-sm"),
  div(class = "note", style = "margin-top:.75rem",
      textOutput("n_rows", inline = TRUE), br(),
      "Synthetic data created for a university project. Amounts in Rwandan francs (RWF).")
)

# =============================================================================
#  UI
# =============================================================================
ui <- page_navbar(
  title = span(span(class = "brand-title", icon("cart-shopping"), " Umucyo Supermarket"),
               span(class = "brand-sub", "Retail Market Intelligence")),
  theme = theme, fillable = FALSE, sidebar = filters,
  header = tags$head(tags$style(HTML(css))),

  # ---------------------------------------------------------------- Overview
  nav_panel("Overview", icon = icon("gauge-high"),
    layout_column_wrap(width = 1/3, fill = FALSE, heights_equal = "row",
      uiOutput("vb_revenue"), uiOutput("vb_profit"), uiOutput("vb_sales"),
      uiOutput("vb_basket"), uiOutput("vb_customers"), uiOutput("vb_lost")),
    layout_columns(col_widths = c(8, 4),
      card(full_screen = TRUE, height = 420,
           card_header(class = "d-flex justify-content-between align-items-center",
                       HTML("Revenue over time<span class='sub'>Net revenue = completed sales minus returns</span>"),
                       radioButtons("trend_view", NULL, c("Timeline" = "line", "Compare years" = "years"),
                                    inline = TRUE)),
           plotlyOutput("p_trend")),
      card(height = 420, card_h("Key insights", "Updated live from your filters"), uiOutput("insights"))),
    layout_columns(col_widths = c(6, 6),
      card(full_screen = TRUE, height = 380, card_h("Revenue and profit by category"), plotlyOutput("p_cat")),
      card(full_screen = TRUE, height = 380, card_h("Revenue by region", "Known customers"), plotlyOutput("p_region")))
  ),

  # ---------------------------------------------------------------- Sales & channels
  nav_panel("Sales & Channels", icon = icon("chart-line"),
    layout_columns(col_widths = c(7, 5),
      card(full_screen = TRUE, height = 400,
           card_h("When do customers buy?", "Average net revenue per day, by weekday and month"),
           plotlyOutput("p_heat")),
      card(full_screen = TRUE, height = 400, card_h("Monthly seasonality", "Share of yearly revenue in each month"),
           plotlyOutput("p_season"))),
    layout_columns(col_widths = c(5, 7),
      card(full_screen = TRUE, height = 390, card_h("Sales channel", "Net revenue and average sale value"),
           plotlyOutput("p_channel")),
      card(full_screen = TRUE, height = 390, card_h("Payment methods by channel", "Share of channel revenue (%)"),
           plotlyOutput("p_payment"))),
    card(full_screen = TRUE, height = 360, card_h("Returns and cancellations", "Lost value by category and status"),
         plotlyOutput("p_lost"))
  ),

  # ---------------------------------------------------------------- Products
  nav_panel("Products", icon = icon("box-open"),
    layout_columns(col_widths = c(7, 5),
      card(full_screen = TRUE, height = 470,
           card_header(class = "d-flex justify-content-between align-items-center flex-wrap gap-2",
                       "Top products",
                       div(class = "d-flex gap-3 align-items-center",
                           radioButtons("prod_metric", NULL, c("Revenue" = "net_revenue", "Profit" = "profit",
                                                               "Items sold" = "quantity"), inline = TRUE),
                           div(style = "width:150px", sliderInput("top_n", NULL, 5, 25, 10, step = 1, ticks = FALSE)))),
           plotlyOutput("p_top")),
      card(full_screen = TRUE, height = 470, card_h("Category → product map", "Box size = net revenue. Click to zoom in."),
           plotlyOutput("p_tree"))),
    layout_columns(col_widths = c(5, 7),
      card(full_screen = TRUE, height = 420, card_h("Profit margin by category", "Profit ÷ net revenue"),
           plotlyOutput("p_margin")),
      card(full_screen = TRUE, card_header(class = "d-flex justify-content-between align-items-center",
                                           "Product table", downloadButton("dl_products", "CSV", class = "btn-sm btn-outline-primary")),
           DTOutput("t_products")))
  ),

  # ---------------------------------------------------------------- Customers
  nav_panel("Customers", icon = icon("users"),
    layout_column_wrap(width = 1/4, fill = FALSE, uiOutput("vb_c1"), uiOutput("vb_c2"), uiOutput("vb_c3"), uiOutput("vb_c4")),
    layout_columns(col_widths = c(7, 5),
      card(full_screen = TRUE, height = 450, card_h("Purchase frequency vs total spending", "One dot = one customer · hover for details"),
           plotlyOutput("p_scatter")),
      card(full_screen = TRUE, height = 450, card_h("Membership levels", "Average per customer · error bars = 95% confidence interval"),
           radioButtons("mem_metric", NULL, c("Total spent" = "total_spent", "Purchases" = "purchases",
                                              "Average basket" = "avg_sale_value"), inline = TRUE),
           plotlyOutput("p_member"))),
    layout_columns(col_widths = c(5, 7),
      card(full_screen = TRUE, height = 430,
           card_h("RFM customer segments", "Recency · Frequency · Monetary value (scored 1–5)"),
           plotlyOutput("p_rfm")),
      card(full_screen = TRUE, height = 430, card_h("Who are our customers?", "Customers by age group and gender"),
           plotlyOutput("p_demo"))),
    card(full_screen = TRUE, card_header(class = "d-flex justify-content-between align-items-center",
                                         "Customer table", downloadButton("dl_customers", "CSV", class = "btn-sm btn-outline-primary")),
         DTOutput("t_customers"))
  ),

  # ---------------------------------------------------------------- Statistics
  nav_panel("Statistics", icon = icon("square-root-variable"),
    card(card_h("Descriptive statistics", "Calculated live for the filtered data"), DTOutput("t_desc", fill = FALSE)),
    layout_columns(col_widths = c(6, 6),
      card(full_screen = TRUE,
           card_h("Correlation test", "Is there a relationship between two customer measures?"),
           layout_columns(col_widths = c(6, 6),
             selectInput("cor_x", "X variable", c("Purchases" = "purchases", "Total spent" = "total_spent",
                                                  "Average basket" = "avg_sale_value", "Days since last purchase" = "recency_days",
                                                  "Age" = "age"), selected = "purchases"),
             selectInput("cor_y", "Y variable", c("Total spent" = "total_spent", "Purchases" = "purchases",
                                                  "Average basket" = "avg_sale_value", "Days since last purchase" = "recency_days",
                                                  "Age" = "age"), selected = "total_spent")),
           plotlyOutput("p_cor", height = "300px"), uiOutput("cor_text")),
      card(full_screen = TRUE,
           card_h("Compare two groups", "Welch t-test, Mann-Whitney test and 95% confidence interval"),
           layout_columns(col_widths = c(4, 4, 4),
             selectInput("grp_var", "Group by", c("Membership" = "membership", "Region" = "region", "Gender" = "gender")),
             uiOutput("grp_levels"),
             selectInput("grp_metric", "Measure", c("Total spent" = "total_spent", "Average basket" = "avg_sale_value",
                                                    "Purchases" = "purchases"))),
           plotlyOutput("p_grp", height = "300px"), uiOutput("grp_text"))),
    card(card_h("Chi-square test of independence", "Are two categories related?"),
         layout_columns(col_widths = c(3, 3, 6),
           selectInput("chi_a", "Variable A", c("Sales channel" = "sales_channel", "Payment method" = "payment_method",
                                                 "Category" = "category", "Membership" = "membership", "Status" = "status",
                                                 "Weekend" = "is_weekend"), selected = "sales_channel"),
           selectInput("chi_b", "Variable B", c("Payment method" = "payment_method", "Sales channel" = "sales_channel",
                                                 "Category" = "category", "Membership" = "membership", "Status" = "status",
                                                 "Weekend" = "is_weekend"), selected = "payment_method"),
           uiOutput("chi_text")),
         plotlyOutput("p_chi", height = "320px"))
  ),

  # ---------------------------------------------------------------- Data quality
  nav_panel("Data Quality", icon = icon("broom"),
    layout_column_wrap(width = 1/4, fill = FALSE,
      uiOutput("vb_q1"), uiOutput("vb_q2"), uiOutput("vb_q3"), uiOutput("vb_q4")),
    layout_columns(col_widths = c(6, 6),
      card(full_screen = TRUE, height = 400, card_h("Missing values in the raw files", "Number of empty cells per column"),
           plotlyOutput("p_missing")),
      card(full_screen = TRUE, height = 400, card_h("Raw vs clean row counts", "Duplicates and outliers removed during cleaning"),
           plotlyOutput("p_rows"))),
    card(full_screen = TRUE, card_h("Cleaning log", "Every cleaning decision made in the Python notebook"), DTOutput("t_log")),
    card(full_screen = TRUE, card_h("Rows removed as outliers", "Kept here for transparency"), DTOutput("t_removed"))
  ),

  nav_spacer(),
  nav_item(tags$span(class = "nav-link", style = "font-size:.8rem", icon("database"), " Synthetic data · RWF"))
)

# =============================================================================
#  SERVER
# =============================================================================
server <- function(input, output, session) {

  observeEvent(input$reset, {
    updateDateRangeInput(session, "dates", start = min(retail$date), end = max(retail$date))
    for (id in c("region", "category", "channel", "membership")) updateSelectizeInput(session, id, selected = character(0))
    updateCheckboxGroupInput(session, "status", selected = c("Completed", "Returned", "Cancelled"))
  })

  # ---- Filtered data ----------------------------------------------------------
  filtered <- reactive({
    req(input$dates)
    d <- retail |> filter(date >= input$dates[1], date <= input$dates[2])
    if (length(input$region))     d <- d |> filter(region %in% input$region)
    if (length(input$category))   d <- d |> filter(category %in% input$category)
    if (length(input$channel))    d <- d |> filter(sales_channel %in% input$channel)
    if (length(input$membership)) d <- d |> filter(membership %in% input$membership)
    d |> filter(status %in% input$status)
  })
  output$n_rows <- renderText(paste0(fmt_int(nrow(filtered())), " of ", fmt_int(nrow(retail)), " sales shown."))
  has_data <- function(d) validate(need(nrow(d) > 0, "No sales match the selected filters. Try widening them."))

  # Customer-level table (one row per known customer)
  customers <- reactive({
    d <- filtered() |> filter(is_known_customer)
    if (!nrow(d)) return(tibble())
    end <- max(retail$date)
    out <- d |>
      group_by(customer_id, membership, region, gender, age, age_group) |>
      summarise(purchases = sum(status == "Completed"),
                total_spent = sum(net_revenue),
                avg_sale_value = if (any(status == "Completed")) mean(net_revenue[status == "Completed"]) else NA_real_,
                last_purchase = if (any(status == "Completed")) max(date[status == "Completed"]) else as.Date(NA),
                .groups = "drop") |>
      filter(purchases > 0) |>
      mutate(recency_days = as.numeric(end - last_purchase),
             membership = droplevels(membership))
    if (nrow(out) >= 5) {
      out <- out |>
        mutate(R = 6L - ntile(recency_days, 5), F = ntile(purchases, 5), M = ntile(total_spent, 5),
               segment = case_when(R >= 4 & F >= 4 ~ "Champions",
                                   R >= 3 & F >= 3 ~ "Loyal customers",
                                   R >= 4 & F <= 2 ~ "New / promising",
                                   R <= 2 & F >= 3 ~ "At risk",
                                   TRUE            ~ "Hibernating"))
    } else out$segment <- "Too few customers"
    out
  })

  # ---- Value boxes ------------------------------------------------------------
  vb <- function(title, value, sub, icon_name, bg, fg = "#ffffff") {
    value_box(title = title, value = value, p(sub), showcase = icon(icon_name),
              theme = value_box_theme(bg = bg, fg = fg))
  }
  totals <- reactive({
    d <- filtered()
    done <- d |> filter(status == "Completed")
    list(rev = sum(d$net_revenue), profit = sum(d$profit),
         margin = if (sum(d$net_revenue) > 0) 100 * sum(d$profit) / sum(d$net_revenue) else NA,
         sales = nrow(done), basket = if (nrow(done)) mean(done$net_revenue) else NA,
         median_basket = if (nrow(done)) median(done$net_revenue) else NA,
         customers = n_distinct(d$customer_id[d$is_known_customer]),
         lost = sum(d$lost_value),
         lost_pct = if (sum(done$net_revenue) > 0) 100 * sum(d$lost_value) / sum(done$net_revenue) else NA,
         problem = sum(d$status != "Completed"))
  })
  output$vb_revenue <- renderUI(vb("Net revenue", paste(fmt_rwf(totals()$rev), "RWF"),
                                   "Completed sales minus returns", "sack-dollar", "#12355b"))
  output$vb_profit <- renderUI(vb("Profit", paste(fmt_rwf(totals()$profit), "RWF"),
                                  sprintf("Margin %.1f%%", totals()$margin), "chart-pie", "#1f5fa8"))
  output$vb_sales <- renderUI(vb("Completed sales", fmt_int(totals()$sales),
                                 paste(fmt_int(totals()$problem), "returned or cancelled"), "receipt", COL$primary))
  output$vb_basket <- renderUI(vb("Average sale value", paste(fmt_int(round(totals()$basket)), "RWF"),
                                  paste("Median", fmt_int(round(totals()$median_basket)), "RWF"), "basket-shopping", "#0f8a63"))
  output$vb_customers <- renderUI(vb("Active customers", fmt_int(totals()$customers),
                                     "Known customers who bought", "user-group", COL$aqua))
  output$vb_lost <- renderUI(vb("Lost to returns & cancellations", paste(fmt_rwf(totals()$lost), "RWF"),
                                sprintf("%.1f%% of completed-sales revenue", totals()$lost_pct),
                                "rotate-left", "#c2410c"))

  # ---- Overview charts ----------------------------------------------------------
  output$p_trend <- renderPlotly({
    d <- filtered(); has_data(d)
    m <- d |> mutate(month_start = as.Date(paste0(year_month, "-01"))) |>
      group_by(month_start, year, month) |> summarise(rev = sum(net_revenue), sales = sum(status == "Completed"), .groups = "drop")
    if (input$trend_view == "years") {
      p <- plot_ly()
      yrs <- sort(unique(m$year))
      for (i in seq_along(yrs)) {
        y <- m |> filter(year == yrs[i])
        p <- p |> add_trace(data = y, x = ~month.abb[month], y = ~rev, type = "scatter", mode = "lines+markers",
                            name = as.character(yrs[i]), line = list(color = CAT_COLS[i], width = 3),
                            marker = list(size = 8, color = CAT_COLS[i]),
                            hovertemplate = paste0("<b>%{x} ", yrs[i], "</b><br>%{y:,.0f} RWF<extra></extra>"))
      }
      p |> layout(xaxis = list(categoryorder = "array", categoryarray = month.abb)) |>
        style_plot(NULL, "Net revenue (RWF)")
    } else {
      m <- m |> arrange(month_start) |> mutate(avg3 = as.numeric(stats::filter(rev, rep(1/3, 3), sides = 1)))
      plot_ly(m, x = ~month_start) |>
        add_trace(y = ~rev, type = "scatter", mode = "lines+markers", name = "Monthly revenue", fill = "tozeroy",
                  fillcolor = "rgba(42,120,214,0.10)", line = list(color = COL$primary, width = 3),
                  marker = list(size = 7, color = COL$primary),
                  customdata = ~sales,
                  hovertemplate = "<b>%{x|%b %Y}</b><br>Revenue: %{y:,.0f} RWF<br>Completed sales: %{customdata}<extra></extra>") |>
        add_trace(y = ~avg3, type = "scatter", mode = "lines", name = "3-month average",
                  line = list(color = COL$orange, width = 2, dash = "dot"),
                  hovertemplate = "3-month avg: %{y:,.0f} RWF<extra></extra>") |>
        style_plot(NULL, "Net revenue (RWF)") |> layout(hovermode = "x unified")
    }
  })

  output$insights <- renderUI({
    d <- filtered(); validate(need(nrow(d) > 0, "No data for these filters."))
    by_m <- d |> group_by(month_name, month) |> summarise(rev = sum(net_revenue), .groups = "drop") |> arrange(desc(rev))
    by_c <- d |> group_by(category) |> summarise(rev = sum(net_revenue), pr = sum(profit), .groups = "drop") |>
      mutate(margin = pr / rev) |> arrange(desc(rev))
    best_margin <- by_c |> filter(rev > 0) |> arrange(desc(margin)) |> slice(1)
    ch <- d |> group_by(sales_channel) |> summarise(rev = sum(net_revenue), .groups = "drop") |> mutate(s = rev / sum(rev)) |> arrange(desc(rev))
    pay <- d |> filter(status == "Completed") |> count(payment_method) |> mutate(s = n / sum(n)) |> arrange(desc(n))
    cu <- customers()
    items <- list(
      div(class = "insight", icon("calendar-days"), HTML(sprintf(" <b>%s</b> is the strongest month, with %s RWF in total.",
                                                                    month.name[by_m$month[1]], fmt_rwf(by_m$rev[1])))),
      div(class = "insight", icon("trophy"), HTML(sprintf(" <b>%s</b> is the top category (%.0f%% of revenue).",
                                                             by_c$category[1], 100 * by_c$rev[1] / sum(by_c$rev)))),
      div(class = "insight good", icon("percent"), HTML(sprintf(" Best profit margin: <b>%s</b> (%.0f%%).",
                                                                   best_margin$category, 100 * best_margin$margin))),
      div(class = "insight", icon("store"), HTML(sprintf(" <b>%s</b> brings %.0f%% of revenue; <b>%s</b> is used for %.0f%% of sales.",
                                                            ch$sales_channel[1], 100 * ch$s[1], pay$payment_method[1], 100 * pay$s[1])))
    )
    if (nrow(cu) > 10) {
      r <- suppressWarnings(cor(cu$purchases, cu$total_spent, method = "spearman"))
      items <- c(items, list(div(class = "insight warn", icon("repeat"),
        HTML(sprintf(" Frequent buyers spend more: Spearman ρ = <b>%.2f</b> between purchases and spending.", r)))))
    }
    tagList(items)
  })

  output$p_cat <- renderPlotly({
    d <- filtered(); has_data(d)
    c <- d |> group_by(category) |> summarise(rev = sum(net_revenue), profit = sum(profit), .groups = "drop") |> arrange(rev)
    c$category <- factor(c$category, levels = c$category)
    plot_ly(c, y = ~category) |>
      add_bars(x = ~rev, name = "Net revenue", marker = list(color = COL$primary),
               hovertemplate = "<b>%{y}</b><br>Revenue: %{x:,.0f} RWF<extra></extra>") |>
      add_bars(x = ~profit, name = "Profit", marker = list(color = COL$orange),
               hovertemplate = "<b>%{y}</b><br>Profit: %{x:,.0f} RWF<extra></extra>") |>
      layout(barmode = "group", bargap = 0.25) |> style_plot("RWF", NULL)
  })

  output$p_region <- renderPlotly({
    d <- filtered() |> filter(is_known_customer); has_data(d)
    r <- d |> group_by(region) |> summarise(rev = sum(net_revenue), cust = n_distinct(customer_id), .groups = "drop") |>
      mutate(share = rev / sum(rev), per_cust = rev / cust) |> arrange(rev)
    r$region <- factor(r$region, levels = r$region)
    plot_ly(r, x = ~rev, y = ~region, type = "bar", marker = list(color = COL$primary),
            text = ~sprintf("%.0f%%", 100 * share), textposition = "outside", cliponaxis = FALSE,
            customdata = ~cbind(cust, round(per_cust)),
            hovertemplate = "<b>%{y}</b><br>Revenue: %{x:,.0f} RWF<br>Customers: %{customdata[0]}<br>Per customer: %{customdata[1]:,} RWF<extra></extra>") |>
      style_plot("Net revenue (RWF)", NULL, legend = FALSE)
  })

  # ---- Sales & channels ---------------------------------------------------------
  output$p_heat <- renderPlotly({
    d <- filtered(); has_data(d)
    daily <- d |> group_by(date, day_of_week, month) |> summarise(rev = sum(net_revenue), .groups = "drop")
    h <- daily |> group_by(day_of_week, month) |> summarise(avg = mean(rev), .groups = "drop") |>
      complete(day_of_week, month = 1:12)
    z <- h |> mutate(m = month.abb[month]) |> select(day_of_week, m, avg) |>
      pivot_wider(names_from = m, values_from = avg) |> arrange(day_of_week)
    mat <- as.matrix(z[, intersect(month.abb, names(z))])
    plot_ly(x = colnames(mat), y = as.character(z$day_of_week), z = mat, type = "heatmap",
            colorscale = list(c(0, "#eef5fd"), c(0.5, "#6aa5e8"), c(1, "#12355b")),
            hovertemplate = "<b>%{y}, %{x}</b><br>Average per day: %{z:,.0f} RWF<extra></extra>",
            colorbar = list(title = "RWF/day", thickness = 12)) |>
      style_plot(NULL, NULL, legend = FALSE) |> layout(yaxis = list(autorange = "reversed"))
  })

  output$p_season <- renderPlotly({
    d <- filtered(); has_data(d)
    s <- d |> group_by(month) |> summarise(rev = sum(net_revenue), .groups = "drop") |> mutate(share = rev / sum(rev))
    top <- s$month[which.max(s$share)]
    plot_ly(s, x = ~month.abb[month], y = ~share, type = "bar",
            marker = list(color = ifelse(s$month == top, COL$orange, COL$primary)),
            hovertemplate = "<b>%{x}</b><br>%{y:.1%} of revenue<extra></extra>") |>
      layout(xaxis = list(categoryorder = "array", categoryarray = month.abb), yaxis = list(tickformat = ".0%")) |>
      style_plot(NULL, "Share of revenue", legend = FALSE)
  })

  output$p_channel <- renderPlotly({
    d <- filtered() |> filter(status == "Completed"); has_data(d)
    c <- d |> group_by(sales_channel) |> summarise(rev = sum(net_revenue), avg = mean(net_revenue), n = n(), .groups = "drop") |>
      arrange(desc(rev))
    plot_ly(c, x = ~sales_channel, y = ~rev, type = "bar", marker = list(color = colour_for(as.character(c$sales_channel))),
            text = ~paste0("avg ", fmt_int(round(avg)), " RWF / sale"), textposition = "outside", cliponaxis = FALSE,
            customdata = ~n, hovertemplate = "<b>%{x}</b><br>Revenue: %{y:,.0f} RWF<br>Sales: %{customdata:,}<extra></extra>") |>
      layout(xaxis = list(categoryorder = "array", categoryarray = c$sales_channel)) |>
      style_plot(NULL, "Net revenue (RWF)", legend = FALSE)
  })

  output$p_payment <- renderPlotly({
    d <- filtered() |> filter(status == "Completed"); has_data(d)
    pm <- d |> group_by(sales_channel, payment_method) |> summarise(rev = sum(net_revenue), .groups = "drop") |>
      group_by(sales_channel) |> mutate(share = rev / sum(rev)) |> ungroup()
    pay_cols <- PAY_COLS
    p <- plot_ly()
    for (pmeth in intersect(names(pay_cols), unique(pm$payment_method))) {
      x <- pm |> filter(payment_method == pmeth)
      p <- p |> add_bars(data = x, y = ~sales_channel, x = ~share, name = pmeth, orientation = "h",
                         marker = list(color = pay_cols[[pmeth]], line = list(color = "white", width = 1.5)),
                         hovertemplate = paste0("<b>%{y}</b><br>", pmeth, ": %{x:.1%}<extra></extra>"))
    }
    p |> style_plot(NULL, NULL) |> layout(barmode = "stack", xaxis = list(tickformat = ".0%"), legend = list(traceorder = "normal"))
  })

  output$p_lost <- renderPlotly({
    d <- filtered() |> filter(status != "Completed")
    if (!nrow(d)) return(empty_plot("No returned or cancelled sales in the current selection"))
    l <- d |> group_by(category, status) |> summarise(lost = sum(lost_value), n = n(), .groups = "drop")
    ord <- l |> group_by(category) |> summarise(t = sum(lost)) |> arrange(desc(t)) |> pull(category)
    p <- plot_ly()
    for (s in intersect(c("Returned", "Cancelled"), unique(l$status))) {
      x <- l |> filter(status == s)
      p <- p |> add_bars(data = x, x = ~category, y = ~lost, name = s, marker = list(color = STATUS_COLS[[s]]),
                         customdata = ~n, hovertemplate = paste0("<b>%{x}</b><br>", s, ": %{y:,.0f} RWF (%{customdata} sales)<extra></extra>"))
    }
    p |> layout(barmode = "stack", xaxis = list(categoryorder = "array", categoryarray = ord)) |>
      style_plot(NULL, "Lost value (RWF)")
  })

  # ---- Products -------------------------------------------------------------------
  products <- reactive({
    filtered() |> group_by(product_id, product_name, category) |>
      summarise(net_revenue = sum(net_revenue), profit = sum(profit), quantity = sum(quantity),
                sales = sum(status == "Completed"), returns_cancels = sum(status != "Completed"), .groups = "drop") |>
      mutate(margin_pct = ifelse(net_revenue > 0, round(100 * profit / net_revenue, 1), NA))
  })
  output$p_top <- renderPlotly({
    p <- products(); validate(need(nrow(p) > 0, "No products for these filters."))
    metric <- input$prod_metric
    lab <- c(net_revenue = "Net revenue (RWF)", profit = "Profit (RWF)", quantity = "Items sold")[[metric]]
    t <- p |> arrange(desc(.data[[metric]])) |> slice_head(n = input$top_n) |> arrange(.data[[metric]])
    t$product_name <- factor(t$product_name, levels = t$product_name)
    plot_ly(t, x = ~get(metric), y = ~product_name, type = "bar", color = ~category, colors = CATEGORY_COLS,
            customdata = ~category,
            hovertemplate = paste0("<b>%{y}</b> (%{customdata})<br>", lab, ": %{x:,.0f}<extra></extra>")) |>
      style_plot(lab, NULL) |> layout(yaxis = list(categoryorder = "array", categoryarray = levels(t$product_name)))
  })
  output$p_tree <- renderPlotly({
    p <- products() |> filter(net_revenue > 0); validate(need(nrow(p) > 0, "No products for these filters."))
    cats <- p |> group_by(category) |> summarise(net_revenue = sum(net_revenue), .groups = "drop")
    cat_col <- CATEGORY_COLS
    plot_ly(type = "treemap", branchvalues = "total",
            ids = c(cats$category, paste(p$category, p$product_name, sep = "/")),
            labels = c(cats$category, p$product_name),
            parents = c(rep("", nrow(cats)), p$category),
            values = c(cats$net_revenue, p$net_revenue),
            marker = list(colors = c(cat_col[cats$category], cat_col[p$category]), line = list(color = "white", width = 2)),
            texttemplate = "<b>%{label}</b><br>%{value:,.0f}",
            hovertemplate = "<b>%{label}</b><br>%{value:,.0f} RWF<br>%{percentParent:.1%} of parent<extra></extra>") |>
      layout(margin = list(l = 0, r = 0, t = 0, b = 0), paper_bgcolor = "rgba(0,0,0,0)") |> config(displaylogo = FALSE)
  })
  output$p_margin <- renderPlotly({
    d <- filtered(); has_data(d)
    m <- d |> group_by(category) |> summarise(rev = sum(net_revenue), pr = sum(profit), .groups = "drop") |>
      filter(rev > 0) |> mutate(margin = pr / rev) |> arrange(margin)
    m$category <- factor(m$category, levels = m$category)
    avg <- sum(m$pr) / sum(m$rev)
    plot_ly(m, x = ~margin, y = ~category, type = "bar",
            marker = list(color = ifelse(m$margin >= avg, COL$aqua, "#9db8d9")),
            text = ~sprintf("%.1f%%", 100 * margin), textposition = "outside", cliponaxis = FALSE,
            hovertemplate = "<b>%{y}</b><br>Margin: %{x:.1%}<extra></extra>") |>
      layout(xaxis = list(tickformat = ".0%", range = c(0, max(m$margin) * 1.25)),
             shapes = list(list(type = "line", x0 = avg, x1 = avg, y0 = 0, y1 = 1, yref = "paper",
                                line = list(color = COL$ink, dash = "dot", width = 1.5))),
             annotations = list(list(x = avg, y = 1.04, yref = "paper", text = sprintf("Shop average %.1f%%", 100 * avg),
                                     showarrow = FALSE, font = list(size = 11, color = COL$ink)))) |>
      style_plot("Profit margin", NULL, legend = FALSE)
  })
  output$t_products <- renderDT({
    datatable(products() |> arrange(desc(net_revenue)) |>
                select(Product = product_name, Category = category, `Net revenue` = net_revenue, Profit = profit,
                       `Margin %` = margin_pct, `Items sold` = quantity, `Completed sales` = sales,
                       `Returned / cancelled` = returns_cancels),
              rownames = FALSE, options = list(pageLength = 8, scrollX = TRUE, dom = "ftip")) |>
      formatCurrency(c("Net revenue", "Profit"), currency = "", digits = 0) |>
      formatStyle("Net revenue", background = styleColorBar(c(0, max(products()$net_revenue)), "#d6e6f9"),
                  backgroundSize = "95% 70%", backgroundRepeat = "no-repeat", backgroundPosition = "center")
  })
  output$dl_products <- downloadHandler(function() "products_summary.csv", function(f) write_csv(products(), f))

  # ---- Customers ------------------------------------------------------------------
  output$vb_c1 <- renderUI({ cu <- customers(); vb("Customers", fmt_int(nrow(cu)), "with a completed purchase", "users", "#12355b") })
  output$vb_c2 <- renderUI({ cu <- customers(); vb("Avg purchases", if (nrow(cu)) sprintf("%.1f", mean(cu$purchases)) else "–",
                                                   if (nrow(cu)) paste("Median", median(cu$purchases)) else "", "repeat", COL$primary) })
  output$vb_c3 <- renderUI({ cu <- customers(); vb("Avg spend / customer", if (nrow(cu)) paste(fmt_rwf(mean(cu$total_spent)), "RWF") else "–",
                                                   if (nrow(cu)) paste("Median", fmt_rwf(median(cu$total_spent)), "RWF") else "", "wallet", "#0f8a63") })
  output$vb_c4 <- renderUI({ cu <- customers()
    rep_rate <- if (nrow(cu)) 100 * mean(cu$purchases > 1) else NA
    vb("Repeat customers", if (nrow(cu)) sprintf("%.0f%%", rep_rate) else "–", "bought more than once", "heart", COL$aqua) })

  output$p_scatter <- renderPlotly({
    cu <- customers(); validate(need(nrow(cu) > 0, "No customers for these filters."))
    p <- plot_ly()
    for (m in levels(cu$membership)) {
      x <- cu |> filter(membership == m)
      p <- p |> add_markers(data = x, x = ~purchases, y = ~total_spent, name = m,
                            marker = list(size = 9, color = MEMBER_COLS[[m]], opacity = 0.75, line = list(color = "white", width = 1)),
                            customdata = ~paste0(customer_id, " · ", region, " · ", segment),
                            hovertemplate = "<b>%{customdata}</b><br>Purchases: %{x}<br>Spent: %{y:,.0f} RWF<extra></extra>")
    }
    if (nrow(cu) > 2) {
      fit <- lm(total_spent ~ purchases, data = cu)
      xs <- range(cu$purchases)
      p <- p |> add_lines(x = xs, y = predict(fit, data.frame(purchases = xs)), name = "Trend line",
                          line = list(color = COL$ink, dash = "dash", width = 1.5), hoverinfo = "skip")
    }
    p |> style_plot("Number of completed purchases", "Total spent (RWF)")
  })

  output$p_member <- renderPlotly({
    cu <- customers(); validate(need(nrow(cu) > 0, "No customers for these filters."))
    metric <- input$mem_metric
    lab <- c(total_spent = "Total spent (RWF)", purchases = "Purchases", avg_sale_value = "Average basket (RWF)")[[metric]]
    m <- cu |> group_by(membership) |>
      summarise(mean = mean(.data[[metric]], na.rm = TRUE), se = sd(.data[[metric]], na.rm = TRUE) / sqrt(n()),
                n = n(), .groups = "drop")
    plot_ly(m, x = ~membership, y = ~mean, type = "bar", marker = list(color = unname(MEMBER_COLS[as.character(m$membership)])),
            error_y = list(type = "data", array = 1.96 * m$se, color = COL$ink, thickness = 1.5, width = 6),
            customdata = ~n, hovertemplate = paste0("<b>%{x}</b><br>Mean: %{y:,.1f}<br>Customers: %{customdata}<extra></extra>")) |>
      style_plot(NULL, lab, legend = FALSE)
  })

  output$p_rfm <- renderPlotly({
    cu <- customers(); validate(need(nrow(cu) >= 5, "Not enough customers for segmentation."))
    seg_order <- c("Champions", "Loyal customers", "New / promising", "At risk", "Hibernating")
    seg_cols <- c(Champions = COL$aqua, `Loyal customers` = COL$primary, `New / promising` = COL$yellow,
                  `At risk` = COL$orange, Hibernating = "#94a3b8")
    s <- cu |> group_by(segment) |> summarise(n = n(), rev = sum(total_spent), .groups = "drop") |>
      mutate(rev_share = rev / sum(rev), segment = factor(segment, levels = rev(seg_order))) |> arrange(segment)
    plot_ly(s, y = ~segment, x = ~n, type = "bar", orientation = "h",
            marker = list(color = unname(seg_cols[as.character(s$segment)])),
            text = ~sprintf("%d customers · %.0f%% of revenue", n, 100 * rev_share), textposition = "auto",
            insidetextfont = list(color = "white"),
            hovertemplate = "<b>%{y}</b><br>%{x} customers<extra></extra>") |>
      style_plot("Number of customers", NULL, legend = FALSE)
  })

  output$p_demo <- renderPlotly({
    cu <- customers(); validate(need(nrow(cu) > 0, "No customers for these filters."))
    dm <- cu |> count(age_group, gender) |> filter(age_group != "Unknown")
    g_cols <- c(Female = COL$magenta, Male = COL$primary, Unknown = "#b8c2cf")
    p <- plot_ly()
    for (g in intersect(names(g_cols), unique(dm$gender))) {
      x <- dm |> filter(gender == g)
      p <- p |> add_bars(data = x, x = ~age_group, y = ~n, name = g, marker = list(color = g_cols[[g]]),
                         hovertemplate = paste0("<b>%{x}</b><br>", g, ": %{y} customers<extra></extra>"))
    }
    p |> layout(barmode = "group") |> style_plot("Age group", "Customers")
  })

  output$t_customers <- renderDT({
    cu <- customers(); validate(need(nrow(cu) > 0, "No customers."))
    datatable(cu |> arrange(desc(total_spent)) |>
                transmute(Customer = customer_id, Membership = membership, Region = region, Gender = gender, Age = age,
                          Purchases = purchases, `Total spent` = round(total_spent), `Avg basket` = round(avg_sale_value),
                          `Days since last purchase` = recency_days, Segment = segment),
              rownames = FALSE, options = list(pageLength = 8, scrollX = TRUE, dom = "ftip")) |>
      formatCurrency(c("Total spent", "Avg basket"), currency = "", digits = 0)
  })
  output$dl_customers <- downloadHandler(function() "customer_summary.csv", function(f) write_csv(customers(), f))

  # ---- Statistics -----------------------------------------------------------------
  output$t_desc <- renderDT({
    d <- filtered(); has_data(d)
    done <- d |> filter(status == "Completed"); cu <- customers()
    desc <- function(x, name) {
      x <- x[!is.na(x)]
      if (length(x) < 2) return(NULL)
      tibble(Measure = name, n = length(x), Mean = mean(x), Median = median(x), Variance = var(x), `Std dev` = sd(x),
             Min = min(x), Q1 = quantile(x, .25), Q3 = quantile(x, .75), IQR = IQR(x), Max = max(x))
    }
    tab <- bind_rows(desc(done$net_revenue, "Sale value (RWF)"), desc(done$quantity, "Items per sale"),
                     desc(done$profit, "Profit per sale (RWF)"),
                     if (nrow(cu)) desc(cu$total_spent, "Customer total spending (RWF)"),
                     if (nrow(cu)) desc(cu$purchases, "Purchases per customer"),
                     if (nrow(cu)) desc(cu$age, "Customer age (years)"))
    datatable(tab, rownames = FALSE, options = list(dom = "t", scrollX = TRUE, ordering = FALSE)) |>
      formatRound(names(tab)[-(1:2)], 1)
  })

  output$p_cor <- renderPlotly({
    cu <- customers(); validate(need(nrow(cu) >= 5, "Need at least 5 customers."))
    x <- cu[[input$cor_x]]; y <- cu[[input$cor_y]]
    plot_ly(x = x, y = y, type = "scatter", mode = "markers",
            marker = list(size = 8, color = COL$primary, opacity = 0.6, line = list(color = "white", width = 1)),
            hovertemplate = "x: %{x:,.0f}<br>y: %{y:,.0f}<extra></extra>") |>
      style_plot(VAR_LABELS[[input$cor_x]], VAR_LABELS[[input$cor_y]], legend = FALSE)
  })
  output$cor_text <- renderUI({
    cu <- customers(); req(nrow(cu) >= 5)
    if (input$cor_x == input$cor_y) return(div(class = "insight warn", "Choose two different variables."))
    x <- cu[[input$cor_x]]; y <- cu[[input$cor_y]]
    sp <- suppressWarnings(cor.test(x, y, method = "spearman", exact = FALSE))
    pe <- cor.test(x, y, method = "pearson")
    r <- unname(sp$estimate)
    strength <- as.character(cut(abs(r), c(-Inf, .1, .3, .5, .7, Inf), c("no", "a weak", "a moderate", "a strong", "a very strong")))
    dir <- ifelse(r > 0, "positive", "negative")
    sig <- sp$p.value < 0.05
    tagList(
      layout_columns(col_widths = c(4, 4, 4),
        div(div(class = "stat-label", "Spearman ρ"), div(class = "stat-big", sprintf("%.2f", r))),
        div(div(class = "stat-label", "Pearson r"), div(class = "stat-big", sprintf("%.2f", pe$estimate))),
        div(div(class = "stat-label", "p-value"), div(class = "stat-big", fmt_p(sp$p.value)))),
      div(class = paste("insight", if (sig) "good" else "warn"),
          HTML(sprintf("There is <b>%s %s</b> relationship between <i>%s</i> and <i>%s</i> (n = %d customers). %s",
                       strength, if (strength == "no") "" else dir, VAR_LABELS[[input$cor_x]], VAR_LABELS[[input$cor_y]], length(x),
                       if (sig) "It is statistically significant (p < 0.05). Remember: correlation does not prove cause."
                       else "It is <b>not</b> statistically significant (p ≥ 0.05), so it may be due to chance."))))
  })

  output$grp_levels <- renderUI({
    lv <- sort(unique(as.character(customers()[[input$grp_var]])))
    lv <- setdiff(lv, "Unknown")
    defaults <- if (input$grp_var == "membership" && all(c("Gold", "Regular") %in% lv)) c("Gold", "Regular") else head(lv, 2)
    selectizeInput("grp_pair", "Groups to compare", lv, selected = defaults, multiple = TRUE,
                   options = list(maxItems = 2))
  })
  grp_data <- reactive({
    req(length(input$grp_pair) == 2)
    validate(need(nrow(customers()) > 0, "No customers match the selected filters."))
    customers() |> filter(as.character(.data[[input$grp_var]]) %in% input$grp_pair) |>
      mutate(group = factor(as.character(.data[[input$grp_var]]), levels = input$grp_pair),
             value = .data[[input$grp_metric]]) |> filter(!is.na(value))
  })
  output$p_grp <- renderPlotly({
    g <- grp_data(); validate(need(all(table(g$group) >= 2), "Each group needs at least 2 customers."))
    cols <- c(COL$primary, COL$orange)
    p <- plot_ly()
    for (i in 1:2) {
      lv <- levels(g$group)[i]
      p <- p |> add_boxplot(data = g |> filter(group == lv), y = ~value, name = lv, boxmean = TRUE,
                            marker = list(color = cols[i]), line = list(color = cols[i]),
                            fillcolor = paste0(cols[i], "33"))
    }
    p |> style_plot(NULL, VAR_LABELS[[input$grp_metric]], legend = FALSE)
  })
  output$grp_text <- renderUI({
    g <- grp_data(); req(all(table(g$group) >= 2))
    a <- g$value[g$group == levels(g$group)[1]]; b <- g$value[g$group == levels(g$group)[2]]
    tt <- t.test(a, b); wt <- suppressWarnings(wilcox.test(a, b, exact = FALSE))
    d <- (mean(a) - mean(b)) / sqrt((var(a) + var(b)) / 2)
    size <- as.character(cut(abs(d), c(-Inf, .2, .5, .8, Inf), c("very small", "small", "medium", "large")))
    sig <- tt$p.value < 0.05
    tagList(
      layout_columns(col_widths = c(3, 3, 3, 3),
        div(div(class = "stat-label", paste("Mean", levels(g$group)[1])), div(class = "stat-big", fmt_rwf(mean(a)))),
        div(div(class = "stat-label", paste("Mean", levels(g$group)[2])), div(class = "stat-big", fmt_rwf(mean(b)))),
        div(div(class = "stat-label", "Welch p"), div(class = "stat-big", fmt_p(tt$p.value))),
        div(div(class = "stat-label", "Cohen's d"), div(class = "stat-big", sprintf("%.2f", d)))),
      div(class = paste("insight", if (sig) "good" else "warn"),
          HTML(sprintf(paste0("Difference in means: <b>%s</b> (95%% CI %s to %s). Welch t = %.2f, p %s; Mann-Whitney p %s. ",
                              "%s The effect size is <b>%s</b>."),
                       fmt_rwf(mean(a) - mean(b)), fmt_rwf(tt$conf.int[1]), fmt_rwf(tt$conf.int[2]), tt$statistic,
                       fmt_p(tt$p.value), fmt_p(wt$p.value),
                       if (sig) "We <b>reject H0</b>: the two groups are different." else "We <b>do not reject H0</b>: no clear difference.",
                       size))))
  })

  chi_data <- reactive({
    req(input$chi_a != input$chi_b)
    d <- filtered()
    if (!"status" %in% c(input$chi_a, input$chi_b)) d <- d |> filter(status == "Completed")
    d |> filter(.data[[input$chi_a]] != "Unknown", .data[[input$chi_b]] != "Unknown") |>
      mutate(A = as.character(.data[[input$chi_a]]), B = as.character(.data[[input$chi_b]]))
  })
  output$p_chi <- renderPlotly({
    if (input$chi_a == input$chi_b) return(empty_plot("Choose two different variables"))
    d <- chi_data(); has_data(d)
    tab <- d |> count(A, B) |> group_by(A) |> mutate(share = n / sum(n)) |> ungroup()
    bl <- sort(unique(tab$B))
    bcols <- colour_for(bl)
    p <- plot_ly()
    for (i in seq_along(bl)) {
      x <- tab |> filter(B == bl[i])
      p <- p |> add_bars(data = x, y = ~A, x = ~share, name = bl[i], orientation = "h",
                         marker = list(color = bcols[i], line = list(color = "white", width = 1.5)),
                         customdata = ~n, hovertemplate = paste0("<b>%{y}</b><br>", bl[i], ": %{x:.1%} (%{customdata} sales)<extra></extra>"))
    }
    p |> style_plot("Share within each row", NULL) |>
      layout(barmode = "stack", xaxis = list(tickformat = ".0%"), legend = list(traceorder = "normal"))
  })
  output$chi_text <- renderUI({
    if (input$chi_a == input$chi_b) return(div(class = "insight warn", "Choose two different variables."))
    d <- chi_data(); req(nrow(d) > 0)
    tab <- table(d$A, d$B)
    if (min(dim(tab)) < 2) return(div(class = "insight warn", "Each variable needs at least two categories in the filtered data."))
    ch <- suppressWarnings(chisq.test(tab))
    v <- sqrt(unname(ch$statistic) / (sum(tab) * (min(dim(tab)) - 1)))
    sig <- ch$p.value < 0.05
    div(class = paste("insight", if (sig) "good" else "warn"),
        HTML(sprintf(paste0("χ² = %.2f, df = %d, p %s, Cramér's V = %.2f.<br>",
                            "%s<br><span class='note'>Smallest expected count: %.1f (should be ≥ 5). Uses completed sales only (unless Status is chosen); 'Unknown' values are left out.</span>"),
                     ch$statistic, ch$parameter, fmt_p(ch$p.value), v,
                     if (sig) sprintf("The two variables are <b>related</b> (strength: %s).",
                                      ifelse(v < .1, "very weak", ifelse(v < .3, "weak", ifelse(v < .5, "moderate", "strong"))))
                     else "No evidence that they are related: the mix is about the same in every group.",
                     min(ch$expected))))
  })

  # ---- Data quality ---------------------------------------------------------------
  have_raw <- all(!vapply(raw_files, is.null, logical(1)))
  raw_missing <- if (have_raw) bind_rows(lapply(names(raw_files), function(f) {
    tibble(file = f, column = names(raw_files[[f]]), missing = colSums(is.na(raw_files[[f]])))
  })) |> filter(missing > 0) else tibble()
  raw_rows <- if (have_raw) vapply(raw_files, nrow, numeric(1)) else c(transactions = NA, customers = NA, products = NA)
  raw_dups <- if (have_raw) vapply(raw_files, function(x) sum(duplicated(x)), numeric(1)) else NA
  clean_rows <- c(transactions = nrow(retail),
                  customers = n_distinct(retail$customer_id[retail$is_known_customer]),
                  products = n_distinct(retail$product_id))
  clean_cust <- opt_read("data", "processed", "customers_cleaned.csv")
  clean_prod <- opt_read("data", "processed", "products_cleaned.csv")
  if (!is.null(clean_cust)) clean_rows["customers"] <- nrow(clean_cust)
  if (!is.null(clean_prod)) clean_rows["products"] <- nrow(clean_prod)

  output$vb_q1 <- renderUI(vb("Raw rows", fmt_int(sum(raw_rows)), "in the three original files", "file-csv", "#12355b"))
  output$vb_q2 <- renderUI(vb("Missing cells", fmt_int(sum(raw_missing$missing)), "found in the raw files", "circle-question", COL$yellow, COL$ink))
  output$vb_q3 <- renderUI(vb("Duplicate rows", fmt_int(sum(raw_dups)), "removed during cleaning", "clone", COL$orange))
  output$vb_q4 <- renderUI(vb("Cleaning steps", if (is.null(cleaning_log)) "–" else fmt_int(nrow(cleaning_log)),
                              "documented in the log", "list-check", COL$aqua))

  output$p_missing <- renderPlotly({
    if (!nrow(raw_missing)) return(empty_plot("Raw files not found"))
    m <- raw_missing |> mutate(label = paste0(file, " · ", column)) |> arrange(missing)
    m$label <- factor(m$label, levels = m$label)
    file_cols <- c(transactions = COL$primary, customers = COL$orange, products = COL$aqua)
    plot_ly(m, x = ~missing, y = ~label, type = "bar", color = ~file, colors = file_cols,
            hovertemplate = "<b>%{y}</b><br>%{x} missing<extra></extra>") |>
      style_plot("Missing values", NULL)
  })
  output$p_rows <- renderPlotly({
    if (!have_raw) return(empty_plot("Raw files not found"))
    panels <- lapply(names(raw_rows), function(f) {
      r <- tibble(stage = factor(c("Raw", "Clean"), levels = c("Raw", "Clean")), rows = c(raw_rows[[f]], clean_rows[[f]]))
      plot_ly(r, x = ~stage, y = ~rows, type = "bar", marker = list(color = c("#9db8d9", COL$primary)),
              text = ~fmt_int(rows), textposition = "outside", cliponaxis = FALSE, showlegend = FALSE,
              hovertemplate = paste0("<b>", f, "</b><br>%{x}: %{y:,} rows<extra></extra>")) |>
        layout(yaxis = list(range = c(0, max(r$rows) * 1.2), showticklabels = FALSE, gridcolor = COL$grid),
               annotations = list(list(text = sprintf("<b>%s</b><br>%s removed", f, fmt_int(raw_rows[[f]] - clean_rows[[f]])),
                                       x = 0.5, y = 1.12, xref = "paper", yref = "paper", showarrow = FALSE,
                                       font = list(size = 12, color = COL$ink))))
    })
    subplot(panels, nrows = 1, shareY = FALSE, margin = 0.05) |>
      layout(font = list(family = "Inter, Segoe UI, system-ui, sans-serif", color = COL$ink),
             paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "rgba(0,0,0,0)", margin = list(t = 50)) |>
      config(displaylogo = FALSE)
  })
  output$t_log <- renderDT({
    validate(need(!is.null(cleaning_log), "Run the Python notebook to create outputs/tables/cleaning_log.csv"))
    datatable(cleaning_log, rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE, dom = "ftip"))
  })
  output$t_removed <- renderDT({
    validate(need(!is.null(removed_rows), "No removed_rows.csv found."))
    datatable(removed_rows, rownames = FALSE, options = list(pageLength = 5, scrollX = TRUE, dom = "tip"))
  })

  output$dl_filtered <- downloadHandler(
    filename = function() paste0("umucyo_filtered_", Sys.Date(), ".csv"),
    content = function(f) write_csv(filtered() |> select(-date), f))
}

shinyApp(ui, server)

