# =============================================================================
#  Helper: copies the data files the dashboard needs INTO the dashboard folder.
#  Used by run_dashboard.R and deploy_to_shinyapps.R (you do not need to run it yourself).
#
#  It looks for your project files in this order:
#    1. this folder            (data/processed, data/raw, outputs/tables next to this file)
#    2. the folder one level up (if you placed Umucyo_Shiny_Dashboard inside your project)
#  and copies any file that is missing or newer into dashboard/.
# =============================================================================

sync_data_into_dashboard <- function(project_dir) {
  app_dir <- file.path(project_dir, "dashboard")
  files <- c("data/processed/retail_integrated_clean.csv",          # required
             "data/processed/customers_cleaned.csv",
             "data/processed/products_cleaned.csv",
             "data/raw/transactions.csv", "data/raw/customers.csv", "data/raw/products.csv",
             "outputs/tables/cleaning_log.csv", "outputs/tables/removed_rows.csv")
  # Where to look for the project files: this folder, then up to three folders higher
  # (e.g. submission/r/Umucyo_Shiny_Dashboard -> submission/r -> submission), then PROJECT_FOLDER
  PROJECT_FOLDER <- "C:/Users/tharagirimana/OneDrive - LOLC UNGUKA FINANCE/Desktop/Thacien/Masters In data science/retail_market_intelligence/retail_market_intelligence/submission"
  up1 <- dirname(project_dir); up2 <- dirname(up1); up3 <- dirname(up2)
  sources <- unique(c(project_dir, up1, up2, up3, PROJECT_FOLDER))
  copied <- character()
  for (f in files) {
    dest <- file.path(app_dir, f)
    for (src_root in sources) {
      src <- file.path(src_root, f)
      if (file.exists(src) && normalizePath(src) != normalizePath(dest, mustWork = FALSE)) {
        if (!file.exists(dest) || file.mtime(src) > file.mtime(dest)) {
          dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
          file.copy(src, dest, overwrite = TRUE)
          copied <- c(copied, f)
        }
        break
      }
    }
  }
  if (length(copied)) message("Copied into dashboard/: ", paste(copied, collapse = ", "))

  if (!file.exists(file.path(app_dir, "data/processed/retail_integrated_clean.csv"))) {
    stop("retail_integrated_clean.csv was not found.\n",
         "Put it in  ", file.path(app_dir, "data", "processed"), "\n",
         "or in your project's data/processed folder, then try again.", call. = FALSE)
  }
  optional <- setdiff(files[-1], files[file.exists(file.path(app_dir, files))])
  if (length(optional)) message("Optional files not found (the Data Quality tab will show less): ",
                                paste(basename(optional), collapse = ", "))
  invisible(app_dir)
}
