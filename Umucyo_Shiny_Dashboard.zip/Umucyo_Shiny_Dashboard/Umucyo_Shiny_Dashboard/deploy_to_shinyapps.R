# =============================================================================
#  PUBLISH THE UMUCYO SUPERMARKET DASHBOARD ONLINE  (shinyapps.io)
#  Group 3 · Programming for Data Scientists (Python and R) · ACE-DS, University of Rwanda
# =============================================================================
#
#  WHAT THIS FILE DOES
#    It takes the dashboard in the "dashboard" folder (app.R + its data files),
#    uploads it to your shinyapps.io account, and gives you a public web link
#    that anyone (your lecturer, your group) can open in a browser.
#
#  WHERE THIS FILE MUST BE
#    Keep it in the Umucyo_Shiny_Dashboard folder, next to the "dashboard" folder:
#
#      Umucyo_Shiny_Dashboard/
#      ├── deploy_to_shinyapps.R        <- THIS FILE
#      ├── run_dashboard.R              (opens the dashboard on your computer)
#      ├── sync_data_into_dashboard.R   (copies the data into dashboard/)
#      └── dashboard/
#          ├── app.R                    (the dashboard itself)
#          ├── data/processed/retail_integrated_clean.csv   (required)
#          ├── data/processed/customers_cleaned.csv, products_cleaned.csv
#          ├── data/raw/transactions.csv, customers.csv, products.csv
#          └── outputs/tables/cleaning_log.csv, removed_rows.csv
#
#  HOW TO USE IT (every time you want to publish or update the online version)
#    1. Make sure the dashboard works on your computer first:
#         open run_dashboard.R in RStudio and click "Source".
#    2. Open THIS file in RStudio.
#    3. Click "Source" (top-right of the editor) or press Ctrl + Shift + S.
#    4. Wait 3-5 minutes. The Console shows the progress:
#         - installing packages (first time only)
#         - copying the data into dashboard/
#         - "Uploading bundle", "Building", "Deploying"...
#    5. When it says "Application successfully deployed", your browser opens:
#         https://datawiserwanda.shinyapps.io/umucyo-dashboard/
#    To update the online dashboard later (new data or code), just Source this file again.
#
#  YOUR ACCOUNT DETAILS (STEP 1 below)
#    They come from https://www.shinyapps.io  ->  your name (top right)  ->  Tokens
#    ->  "Show"  ->  "Show secret". Only the account name, token and secret are needed.
#    Your shinyapps.io PASSWORD is NEVER needed here - do not put it in any file.
#
#  SECURITY - READ BEFORE YOU SUBMIT YOUR PROJECT
#    The token and secret work like a password for publishing. After the app is online:
#      - replace them below with "PASTE-YOUR-TOKEN-HERE" / "PASTE-YOUR-SECRET-HERE"
#        before you hand in or share this folder (RStudio remembers your account, so
#        later updates still work), and
#      - if they were ever shared, create a new token on the Tokens page and delete the old one.
#
#  IF SOMETHING GOES WRONG (see the message in the Console)
#    "Fill in ACCOUNT_NAME, TOKEN and SECRET"  -> STEP 1 still has the placeholders.
#    "retail_integrated_clean.csv was not found" -> run the Python notebook, or copy the file
#                                                into dashboard/data/processed/.
#    "Could not install ..." / download errors -> your network blocks CRAN: use another
#                                                network (e.g. phone hotspot), restart R
#                                                (Session > Restart R) and Source again.
#    "HTTP 401" / "Unauthorized"                -> token or secret is wrong or was deleted:
#                                                copy them again from the Tokens page.
#    "You have reached the maximum number of applications" -> on the free plan, archive or
#                                                delete an old app in shinyapps.io first.
#    The link opens but shows "An error has occurred" -> in shinyapps.io open
#                                                Applications > umucyo-dashboard > Logs.
#                                                Most often a data file was not uploaded.
# =============================================================================


# ---- STEP 1: your shinyapps.io account details ---------------------------------
ACCOUNT_NAME <- "datawiserwanda"                             # your shinyapps.io account name
TOKEN        <- "F4D0AD60B5B0C48F705C54A0626A5C15"           # from the Tokens page
SECRET       <- "JfmGSLJVoYEk0z7W3UJeszB43WCgRKjn7qdBK2r3"   # from the Tokens page ("Show secret")
APP_NAME     <- "umucyo-dashboard"                           # part of the web address (letters, numbers, dashes)
APP_TITLE    <- "Umucyo Supermarket - Retail Market Intelligence"


# ---- STEP 2: nothing to change below this line ---------------------------------

# 2a. Find the folder that contains this file (works with RStudio "Source" and with Rscript)
project_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL)
if (is.null(project_dir)) {
  f <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  if (length(f)) project_dir <- dirname(normalizePath(f))
}
if (is.null(project_dir) && requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  p <- rstudioapi::getSourceEditorContext()$path
  if (nzchar(p)) project_dir <- dirname(p)
}
if (is.null(project_dir) || !dir.exists(file.path(project_dir, "dashboard"))) project_dir <- getwd()
if (!dir.exists(file.path(project_dir, "dashboard"))) {
  stop("Cannot find the 'dashboard' folder. Keep deploy_to_shinyapps.R in the Umucyo_Shiny_Dashboard folder ",
       "(next to the 'dashboard' folder) and click Source again.", call. = FALSE)
}
app_dir <- file.path(project_dir, "dashboard")
message("Project folder: ", project_dir)

# 2b. Check that STEP 1 has been filled in
if (grepl("PASTE|your-account", paste(datawiserwanda, F4D0AD60B5B0C48F705C54A0626A5C15, JfmGSLJVoYEk0z7W3UJeszB43WCgRKjn7qdBK2r3))) {
  stop("Fill in ACCOUNT_NAME, TOKEN and SECRET in STEP 1 first (see the instructions at the top).", call. = FALSE)
}

# 2c. Install the packages needed on YOUR computer (first time only).
#     rsconnect does the publishing; the others are detected from app.R and installed on the server.
needed  <- c("rsconnect", "shiny", "bslib", "plotly", "DT", "dplyr", "tidyr", "readr")
mirrors <- c("https://cran.rstudio.com", "https://packagemanager.posit.co/cran/latest", "https://cloud.r-project.org")
is_missing <- function() needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(is_missing())) {
  options(timeout = max(600, getOption("timeout")))
  pkg_type <- if (.Platform$OS.type == "windows") "binary" else getOption("pkgType")
  for (repo in mirrors) {
    todo <- is_missing()
    if (!length(todo)) break
    message("Installing ", paste(todo, collapse = ", "), " from ", repo, " ...")
    try(install.packages(todo, repos = repo, type = pkg_type), silent = TRUE)
  }
  if (length(is_missing())) {
    stop("Could not install: ", paste(is_missing(), collapse = ", "),
         ". Your network may block the downloads - try another network, restart R and Source again.", call. = FALSE)
  }
}

# 2d. Copy the latest data files into dashboard/ so they are uploaded together with app.R
helper <- file.path(project_dir, "sync_data_into_dashboard.R")
if (file.exists(helper)) {
  source(helper, local = TRUE)
  sync_data_into_dashboard(project_dir)
}
if (!file.exists(file.path(app_dir, "data", "processed", "retail_integrated_clean.csv"))) {
  stop("retail_integrated_clean.csv was not found in ", file.path(app_dir, "data", "processed"),
       ". Copy it there (or run the Python notebook) and Source again.", call. = FALSE)
}

# 2e. Choose the files to upload: app.R and the data only (no notes, no old deployment records)
app_files <- list.files(app_dir, recursive = TRUE)
app_files <- app_files[!grepl("PUT_YOUR_FILES_HERE\\.txt$|^rsconnect/|\\.Rhistory$", app_files)]
message("Files to upload (", length(app_files), "):\n  ", paste(app_files, collapse = "\n  "))

# 2f. Connect RStudio to your shinyapps.io account and publish
rsconnect::setAccountInfo(name = datawiserwanda, token = F4D0AD60B5B0C48F705C54A0626A5C15, secret = JfmGSLJVoYEk0z7W3UJeszB43WCgRKjn7qdBK2r3)
rsconnect::deployApp(appDir = app_dir, appFiles = app_files, appName = , appTitle = APP_TITLE,
                     account = ACCOUNT_NAME, server = "shinyapps.io", forceUpdate = TRUE, launch.browser = TRUE)

message("\nDone! Your dashboard is online at:  https://", ACCOUNT_NAME, ".shinyapps.io/", umucyo-dashboard, "/",
        "\nRemember: remove the token and secret from STEP 1 before you submit or share this folder.")

