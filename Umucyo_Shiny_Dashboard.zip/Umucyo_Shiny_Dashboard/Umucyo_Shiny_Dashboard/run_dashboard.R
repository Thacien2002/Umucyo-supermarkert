# =============================================================================
#  ONE-CLICK LAUNCHER for the Umucyo Supermarket dashboard (on your computer)
#
#  In RStudio: open this file and click "Source" (or press Ctrl + Shift + S).
#  It works from any working directory. The first time, it installs the
#  missing packages automatically (this needs internet and can take a few minutes).
# =============================================================================

# Find the folder that contains this file
project_dir <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NULL)
if (is.null(project_dir)) {                                   # started with Rscript
  f <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  if (length(f)) project_dir <- dirname(normalizePath(f))
}
if (is.null(project_dir) && requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  project_dir <- dirname(rstudioapi::getSourceEditorContext()$path)
}
if (is.null(project_dir) || !dir.exists(file.path(project_dir, "dashboard"))) project_dir <- getwd()
if (!dir.exists(file.path(project_dir, "dashboard"))) {
  stop("Cannot find the 'dashboard' folder next to this file. Keep run_dashboard.R in the Umucyo_Shiny_Dashboard folder.",
       call. = FALSE)
}

# Copy the data from the project into dashboard/ (so the same folder can later be deployed)
source(file.path(project_dir, "sync_data_into_dashboard.R"), local = TRUE)
app_dir <- sync_data_into_dashboard(project_dir)

# Make sure shiny is available before calling runApp (app.R installs the rest)
if (!requireNamespace("shiny", quietly = TRUE)) {
  options(timeout = max(600, getOption("timeout")))
  install.packages("shiny", repos = "https://cran.rstudio.com",
                   type = if (.Platform$OS.type == "windows") "binary" else getOption("pkgType"))
}

shiny::runApp(app_dir, launch.browser = TRUE)
